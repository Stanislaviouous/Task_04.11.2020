import pprint
import random
from operator import itemgetter
n = 5
m = 9
k = 8
# Создаём трёхмерный список
listic = [[["0" for i in range(n)] for i in range(m)]for j in range(k)]
#
# Заполняем список
r = 0
for i in range(k):
    for g in range(m):
        for j in range(n):
            listic[i][g][j] = r
            r = r + 1
#
# Перемешиваем список
for i in range(k):
    for g in range(m):
        random.shuffle(listic[i][g])
    random.shuffle(listic[i])
random.shuffle(listic)
#
# Выводим список
lisen = []  # Массив строк вывода
stroke = ""  # Переменная для вывода строки с правильными пробелами
for l in range(m):
    for e in range(k):
        stroke = str(str(stroke) + "  " +
                     str(listic[e][l])).replace("[", "").replace("]", "").replace(",", "")
    stroke = stroke.strip()
    lisen.append(stroke)
    stroke = ""
low = []  # Массив количества пробелов
maxon = 0  # Максимальное значение
for i in range(k):
    for j in range(n):
        for g in range(m):
            if maxon < listic[i][g][j]:
                maxon = listic[i][g][j]
        low.append(len(str(maxon)))
        maxon = 0
for b in range(len(lisen)):
    lisen[b] = lisen[b].split()
    for d in range(len(lisen[b])):
        if d % (n) == 0 and d != 0:
            lisen[b][d] = " " + \
                (" " * (low[d] - len(lisen[b][d]))) + lisen[b][d]
        else:
            lisen[b][d] = (" " * (low[d] - len(lisen[b][d]))) + lisen[b][d]
    print(str(lisen[b]).replace("[", "").replace(
        "]", "").replace(",", "").replace("'", ""))
#
# Сортируем массив
listic.sort(key=itemgetter(0))
for h in range(len(listic)):
    listic[h].sort(key=itemgetter(0))
    for t in range(len(listic[h])):
        listic[h][t].sort()
#
# Выводим список
print()
lisen.clear()  # Массив строк вывода
stroke = ""  # Переменная для вывода строки с правильными пробелами
for l in range(m):
    for e in range(k):
        stroke = str(str(stroke) + "  " +
                     str(listic[e][l])).replace("[", "").replace("]", "").replace(",", "")
    stroke = stroke.strip()
    lisen.append(stroke)
    stroke = ""
low = []  # Массив количества пробелов
maxon = 0  # Максимальное значение
for i in range(k):
    for j in range(n):
        for g in range(m):
            if maxon < listic[i][g][j]:
                maxon = listic[i][g][j]
        low.append(len(str(maxon)))
        maxon = 0
for b in range(len(lisen)):
    lisen[b] = lisen[b].split()
    for d in range(len(lisen[b])):
        if d % (n) == 0 and d != 0:
            lisen[b][d] = " " + \
                (" " * (low[d] - len(lisen[b][d]))) + lisen[b][d]
        else:
            lisen[b][d] = (" " * (low[d] - len(lisen[b][d]))) + lisen[b][d]
    print(str(lisen[b]).replace("[", "").replace(
        "]", "").replace(",", "").replace("'", ""))
#
