def is_correct(*arg):
    equal, val = 0, 0
    for file in arg:
        with open(file, newline="") as input:
            try:
                for i in input.readlines():
                    const = i / 1
                val += sum(file)
            except:
                equal += 1
                pass

    a = (val, equal)
    print(a)


is_correct("fileB.txt", "fileA.txt")
