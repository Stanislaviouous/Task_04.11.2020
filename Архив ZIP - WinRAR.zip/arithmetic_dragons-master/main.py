# coding: utf-8
# license: GPLv3

from tournament import *

print(__name__)

if __name__ == '__main__':
    start_game()
